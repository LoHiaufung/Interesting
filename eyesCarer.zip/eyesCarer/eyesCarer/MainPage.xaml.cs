﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Xml.Linq;
using Windows.Data.Xml.Dom;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x804 上介绍了“空白页”项模板

namespace eyesCarer
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            // 读取xml
            XDocument xd = XDocument.Load("XML/toast.xml");
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xd.ToString());
            // 40分钟后提醒
            DateTimeOffset beginPoint = DateTimeOffset.Now.AddMinutes(40);
            // 发出通知
            ScheduledToastNotification notifier = new  ScheduledToastNotification(doc,beginPoint);
            ToastNotificationManager.CreateToastNotifier().AddToSchedule(notifier);
        }
    }
}
