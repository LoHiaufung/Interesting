﻿using proj.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.Core;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;
using Windows.UI;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Newtonsoft.Json.Linq;

// https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x804 上介绍了“空白页”项模板

namespace proj
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
       
        channelList viewModel { get; set; }
        // string account;
        // string passowrd;
        string userName;
        MessageWebSocket webSock;
        public MainPage()
        {
            this.InitializeComponent();
            rootGrid.DataContext = viewModel;
            viewModel = new channelList();
            bEnteredExited.PointerEntered += sideBarOpenOrClose;
            bEnteredExited.PointerExited += sideBarOpenOrClose;

            // initial
            changeChannel(viewModel.getAllChannel[0].sourceUri);
            webSock = new MessageWebSocket();

            //In this case we will be sending/receiving a string so we need to set the MessageType to Utf8.
            webSock.Control.MessageType = SocketMessageType.Utf8;

            //Add the MessageReceived event handler.
            webSock.MessageReceived += WebSock_MessageReceived;

            //Add the Closed event handler.
            webSock.Closed += WebSock_Closed;
        }


        private void sideBarOpenOrClose(object sender, RoutedEventArgs e)
        {
            SL.IsPaneOpen = !SL.IsPaneOpen;
        }

        private void TodoItem_ItemClicked(object sender, ItemClickEventArgs e)
        {
            Model.TVchannel SelectedChannel = (Model.TVchannel)(e.ClickedItem);
            changeChannel(SelectedChannel.sourceUri);
        }

        private void changeChannel(string _uri)
        {
            System.Uri manifestUri = new Uri(_uri);
            mediaPlayerElement.Source = MediaSource.CreateFromUri(manifestUri);
            mediaPlayerElement.MediaPlayer.Play();
        }

        
        private void changeChannelById(int cid)
        {
            
        }
        
        private void LoginOrLogout(object sender, RoutedEventArgs e)
        {
            if (userName == null)
            {
                loginDialog.ShowAsync();
            } else
            
            // 关闭连接
            {
                webSock.Close(8888, "正常关闭");
                // the login botton "退出" will be changed to “登陆”
            }
        }

        private void clickToLogin(object sender, RoutedEventArgs e)
        {
            verifyUserAsync();
        }

        private async void showLoginFail()
        {
            var messageDialog = new MessageDialog("账号或密码错误！");
            messageDialog.Commands.Add(new UICommand("OK"));
            await messageDialog.ShowAsync();
        }

        private void clickToCancelLogin(object sender, RoutedEventArgs e)
        {
            loginDialog.Hide();
        }

        private async System.Threading.Tasks.Task verifyUserAsync()
        {

            // 登陆
            // target url
            Uri serverUri = new Uri("ws://123.207.78.54:8001/");
            string userName = accountBox.Text;
            string password = passwordBox.Password;
            // string userName = "r1VgfuVg-";
            // string password = "123";
            // login
            try
            {
                //Connect to the server.
                await webSock.ConnectAsync(serverUri);

                //Send a message to the server.
                await WebSock_SendMessageAsync(webSock, "{\"id\":\"" + userName + "\",\"password\":\"" + password + "\"}");

            }
            catch (Exception ex)
            {
                //Add code here to handle any exceptions
            }
            // loginDialog.Hide();
        }

        private void WebSock_MessageReceived(MessageWebSocket sender, MessageWebSocketMessageReceivedEventArgs args)
        {
            DataReader messageReader = args.GetDataReader();
            messageReader.UnicodeEncoding = UnicodeEncoding.Utf8;
            string messageString = messageReader.ReadString(messageReader.UnconsumedBufferLength);

            //Add code here to do something with the string that is received.
            JObject jo = JObject.Parse(messageString);

            // login, get userName
            if (userName == null && Boolean.Parse(jo["success"].ToString()) == true)
            {
                userName = jo["username"].ToString();
                // 改状态为已登陆
                shellForchangeToLoginedStateAsync();
                // loginDialog.Hide();
            }
            // change channel
            else
            {
                // 如果换台信号就换，否则收到shutdown，关电视
                try
                {
                    int cid = int.Parse(jo["myNum"].ToString());
                    ShellToChangeChannelInUIAsync(cid);
                } catch
                {
                    App.Current.Exit();
                }
            }

        }

        private void WebSock_Closed(IWebSocket sender, WebSocketClosedEventArgs args)
        {
            //Add code here to do something when the connection is closed locally or by the server
            ShellTochangeToNotLoginedStateAsync();
        }
        private async System.Threading.Tasks.Task WebSock_SendMessageAsync(MessageWebSocket webSock, string message)
        {
            DataWriter messageWriter = new DataWriter(webSock.OutputStream);
            messageWriter.WriteString(message);
            await messageWriter.StoreAsync();

        }


        private async System.Threading.Tasks.Task shellForchangeToLoginedStateAsync()
        {
            await changeToLoginedStateAsync(this.userName);
        }
        private async System.Threading.Tasks.Task changeToLoginedStateAsync(string userNmae)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                welcomeText.Text = userName;
                showLoginDialogButton.Content = "退出";
                loginDialog.Hide();
            });
        }

        async System.Threading.Tasks.Task ShellTochangeToNotLoginedStateAsync()
        {
            await changeToNotLoginedStateAsync();
        }
        private async System.Threading.Tasks.Task changeToNotLoginedStateAsync()
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                userName = null;
                showLoginDialogButton.Content = "登陆";
                welcomeText.Text = "尚未登陆";
            });
        }

        private async System.Threading.Tasks.Task ShellToChangeChannelInUIAsync(int cid)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                if (viewModel.isValidCID(cid))
                {
                    mediaPlayerElement.Source = MediaSource.CreateFromUri(viewModel.getUriById(cid));
                    mediaPlayerElement.MediaPlayer.Play();
                }
            });
        }
    }
}
