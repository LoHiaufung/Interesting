﻿using proj.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proj.ViewModel
{
    class channelList
    {
        private ObservableCollection<TVchannel> cLists = new ObservableCollection<TVchannel>();
        public ObservableCollection<TVchannel> getAllChannel{get {return this.cLists;}  }
        
        private int selectedChannelID = 0;
        public int getSelectedChannelID() { return selectedChannelID; }
        public void setSelectedChannelID(int cID) { selectedChannelID = cID; }
        
        public channelList()
        {
            
            // cLists.Add(new TVchannel(0, "CCTV风云音乐", "http://222.191.24.6:6610/2/2/ch00000090990000001214/index.m3u8?ispcode=3"));
            cLists.Add(new TVchannel(0, "CCTV风云音乐", "http://222.191.24.6:6610/2/2/ch00000090990000001214/index.m3u8?ispcode=3"));
            cLists.Add(new TVchannel(1, "CCTV西部旅游", "http://livertmp2-cnc.wasu.cn/zhibo/scgx_xbly/playlist.m3u8"));
            // cLists.Add(new TVchannel(2, "CCTV大众生活", "http://livertmp2-cnc.wasu.cn/zhibo/scgx_dzsh/playlist.m3u8"));
            cLists.Add(new TVchannel(2, "CCTV国防军事", "http://222.191.24.6:6610/2/2/ch00000090990000001205/playlist.m3u8?ispcode=3"));
            cLists.Add(new TVchannel(3, "CCTV-1高清", "http://183.251.61.207/PLTV/88888888/224/3221225812/index.m3u8"));
            cLists.Add(new TVchannel(4, "CCTV-7高清", "http://120.87.4.5/PLTV/88888894/224/3221225492/index.m3u8"));
            cLists.Add(new TVchannel(5, "CCTV-12", "http://183.207.249.15/PLTV/2/224/3221226019/index.m3u8"));
            cLists.Add(new TVchannel(6, "CCTV-14", "http://183.207.249.15/PLTV/2/224/3221226023/index.m3u8"));
            cLists.Add(new TVchannel(7, "CCTV 5+", "http://222.191.24.7:6610/2/2/ch00000090990000001297/index.m3u8?ispcode=3"));
            cLists.Add(new TVchannel(8, "香港31台", "http://rthklive1-lh.akamaihd.net/i/rthk31_1@167495/index_1296_av-p.m3u8"));
            cLists.Add(new TVchannel(9, "香港32台", "http://rthklive2-lh.akamaihd.net/i/rthk32_1@168450/index_1296_av-b.m3u8"));
            cLists.Add(new TVchannel(10, "香港卫视", "http://live.hkstv.hk.lxdns.com/live/hks/playlist.m3u8"));
            cLists.Add(new TVchannel(11, "凤凰中文", "http://119.167.138.7/live/zhongwen.m3u8"));
            cLists.Add(new TVchannel(12, "凤凰资讯", "http://119.167.138.7/live/zixun.m3u8"));
        }

        public void addChannel(int _cID, string _cName, string _sUri)
        {
            this.cLists.Add(new TVchannel(_cID, _cName, _sUri));
        }
        
        public Uri getUriById(int id)
        {
             foreach(TVchannel a in  cLists)
            {
                if(id == a.cID)
                {
                    return new Uri(a.sourceUri);
                }
            }
            return new Uri("NONE!");
        }
        
        public bool isValidCID(int id)
        {
            return 0 <= id && id < cLists.Count();
        }

    }
}
