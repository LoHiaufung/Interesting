﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proj.Model
{
    public class TVchannel
    {
        public TVchannel(int _cID, string _cName, string _sUri)
        {
            this.cID = _cID;
            this.cName = _cName;
            this.sourceUri = _sUri;
        }
        public int cID { get; set; }
        public string cName { get; set; }
        public string sourceUri { get; set; }
    }
}
